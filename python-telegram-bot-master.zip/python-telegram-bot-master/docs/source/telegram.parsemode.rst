telegram.ParseMode
==================

.. autoclass:: telegram.ParseMode
    :members:
    :show-inheritance:
