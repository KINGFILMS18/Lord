telegram.ext.Updater
====================

.. autoclass:: telegram.ext.Updater
    :members:
    :show-inheritance:
