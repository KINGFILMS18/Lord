telegram.ext.ConversationHandler
================================

.. autoclass:: telegram.ext.ConversationHandler
    :members:
    :show-inheritance:
