telegram.ext.filters Module
===========================

.. automodule:: telegram.ext.filters
    :members:
    :show-inheritance:
