telegram.PassportElementErrorFrontSide
======================================

.. autoclass:: telegram.PassportElementErrorFrontSide
    :members:
    :show-inheritance:
