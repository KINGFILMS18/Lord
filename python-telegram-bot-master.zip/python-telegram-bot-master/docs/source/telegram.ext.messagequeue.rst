telegram.ext.MessageQueue
=========================

.. autoclass:: telegram.ext.MessageQueue
    :members:
    :show-inheritance:
    :special-members:
