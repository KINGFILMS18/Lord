telegram.ext.ChosenInlineResultHandler
======================================

.. autoclass:: telegram.ext.ChosenInlineResultHandler
    :members:
    :show-inheritance:
