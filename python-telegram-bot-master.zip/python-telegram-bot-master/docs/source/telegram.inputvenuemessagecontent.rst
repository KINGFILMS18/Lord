telegram.InputVenueMessageContent
=================================

.. autoclass:: telegram.InputVenueMessageContent
    :members:
    :show-inheritance:
