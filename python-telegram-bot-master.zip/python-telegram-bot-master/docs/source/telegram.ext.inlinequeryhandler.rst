telegram.ext.InlineQueryHandler
===============================

.. autoclass:: telegram.ext.InlineQueryHandler
    :members:
    :show-inheritance:
